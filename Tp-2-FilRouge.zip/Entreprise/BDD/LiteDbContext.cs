﻿using Entreprise.Interfaces;
using Entreprise.Services;
using LiteDB;
using System;
using System.Collections.Generic;

namespace Entreprise
{
    public class LiteDbContext : IDisposable, IAjoutableSalarie
    {
        private LiteDatabase liteDatabase;

        public LiteDbContext()
        {
            InitialiserBaseDeDonnees();
        }

        // Retirer la conversion inutile de ILiteCollection
        public ILiteCollection<Salarie> Salaries => liteDatabase.GetCollection<Salarie>("salaries");
        public ILiteCollection<Client> Clients => liteDatabase.GetCollection<Client>("clients");
        public ILiteCollection<Achat> Achats => liteDatabase.GetCollection<Achat>("achats");
        public ILiteCollection<Fournisseur> Fournisseurs => liteDatabase.GetCollection<Fournisseur>("fournisseurs");
        public ILiteCollection<Produit> Produits => liteDatabase.GetCollection<Produit>("produits");

        // Utiliser la propriété Entreprise directement
        public Entreprise Entreprise
        {
            get => liteDatabase.GetCollection<Entreprise>("entreprises").FindAll().FirstOrDefault();
            set => liteDatabase.GetCollection<Entreprise>("entreprises").Update(value);
        }

        private void InitialiserBaseDeDonnees()
        {
            liteDatabase = new LiteDatabase("entreprise.db");

            if (Entreprise == null)
            {
                var entreprise = new Entreprise
                {
                    Nom = "Cesi (CESI)",
                    SIRET = "77572257201109",
                    Adresse = "TOUR PB5, 1 AVENUE DU GENERAL DE GAULLE, 92800 PUTEAUX",
                };

                liteDatabase.GetCollection<Entreprise>("entreprises").Insert(entreprise);
            }
        }

        public void AjouterSalarie()
        {
            var ajoutSalarieService = new AjoutSalarieService(this);
            Console.Clear();
            Console.Write("Nom du salarié : ");
            string nom = Console.ReadLine();

            Console.Write("Prenom du salarié : ");
            string prenom = Console.ReadLine();

            Console.Write("Adresse du salarié : ");
            string adresse = Console.ReadLine();

            Console.Write("Numéro tel. du salarié : ");
            string num_tel = Console.ReadLine();

            Console.Write("Département du salarié : ");
            string departement = Console.ReadLine();

            float salaire;
            while (true)
            {
                Console.Write("Salaire du salarié : ");
                string salaireInput = Console.ReadLine();

                if (float.TryParse(salaireInput, out salaire))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Veuillez saisir un salaire valide.");
                }
            }

            Console.Write("Poste du salarié : ");
            string poste = Console.ReadLine();
            int prochainId = this.ObtenirProchainIdDisponible<Salarie>();

            Salarie nouveauSalarie = new Salarie
            {
                Nom = nom,
                Prenom = prenom,
                Adresse = adresse,
                Telephone = num_tel,
                Departement = departement,
                Salaire = salaire,
                Poste = poste,
                Matricule = "MAT" + prochainId,
                Id = prochainId


            };

            ajoutSalarieService.AjouterSalarie(nouveauSalarie);
        }

        public List<Salarie> ObtenirSalaries()
        {

            return Salaries.FindAll().ToList();
        }

        public int ObtenirProchainIdDisponible<T>()
        {
            // Obtenez la collection correspondante au type T
            var collection = liteDatabase.GetCollection<T>(typeof(T).Name.ToLower());

            // Obtenez tous les IDs existants dans la collection
            var idsExistants = collection.FindAll().Select(item => (int)item.GetType().GetProperty("Id").GetValue(item)).ToList();

            // Trouvez le premier ID non utilisé
            int prochainId = 1;
            while (idsExistants.Contains(prochainId))
            {
                prochainId++;
            }

            return prochainId;
        }



        public void SupprimerSalarie()
        {
            if (this.ObtenirSalaries().Count() != 0)
            {
                foreach (var salaire in this.ObtenirSalaries())
                {
                    Console.WriteLine($"{salaire.Id} - {salaire.Prenom} {salaire.Nom}");
                }

                Console.WriteLine("Saisir l'id du salarié à retirer : ");
                long id_salarie = Convert.ToInt64(Console.ReadLine());
                var collection = liteDatabase.GetCollection<Salarie>("salaries");

                // Recherchez le salarié avec l'ID spécifié
                var salarieASupprimer = collection.FindOne(x => x.Id == id_salarie);
                if (salarieASupprimer != null)
                {
                    // Supprimez le salarié de la collection
                    collection.Delete(id_salarie);

                    // Mettez à jour l'objet Entreprise (si nécessaire)
                    var entreprise = Entreprise;
                    if (entreprise != null)
                    {
                        entreprise.Salaries.Remove(salarieASupprimer);
                        Entreprise = entreprise;
                    }

                    Console.WriteLine($"Salarié avec l'ID {id_salarie} supprimé avec succès.");
                }
                else
                {
                    Console.WriteLine($"Salarié avec l'ID {id_salarie} non trouvé.");
                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("[Erreur] - Il n'y a pas de salariés !");
                Console.ReadLine();
                Console.Clear();
            }

        }

        public void AfficherEntreprise()
        {
            var entreprise = this.Entreprise;
            Console.Clear();
            Console.WriteLine("Informations de l'entreprise:");
            Console.WriteLine($"Nom: {entreprise.Nom}");
            Console.WriteLine($"SIRET: {entreprise.SIRET}");
            Console.WriteLine($"Adresse: {entreprise.Adresse}");
            Console.ReadLine();

        }



        public void Dispose()
        {
            liteDatabase?.Dispose();
        }
    }
}
